import React from "react";
import "./formPair.css";
const FormPair = ({ children }) => {
  return <div className="ui_form_pair">{children}</div>;
};

export default FormPair;
