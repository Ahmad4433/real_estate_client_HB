import React from "react";
import "./lable.css";
const Lable = ({ children }) => {
  return <label className="ui_lable" >{children}</label>;
};

export default Lable;
