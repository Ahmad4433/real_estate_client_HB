import React from "react";
import "./multipair.css";
const MultiPair = ({ children }) => {
  return <div className="multi_pair_main">{children}</div>;
};

export default MultiPair;
